# Reddit API Fetcher

## 📌 Overview
A Python script that interacts with the Reddit API to fetch the **latest 5 posts** from a given subreddit.

## 🚀 Features
✅ **Authenticate with Reddit API** using OAuth  
✅ **Fetch latest 5 posts** with Title, Author, Upvotes, and URL  
✅ **Error handling & API rate limit management**  
✅ **Logging system for debugging**  
✅ **Secure API keys storage via `.env` file**  

---

## 🛠️ Setup Instructions

### 1️⃣ Clone the Repository
```bash
git clone https://github.com/your-username/reddit_api_project.git
cd reddit_api_project
```

### 2️⃣ Install Dependencies
```bash
pip install -r requirements.txt
```

### 3️⃣ Create `.env` file and add your **Reddit API Credentials**
```
REDDIT_CLIENT_ID=your_client_id
REDDIT_CLIENT_SECRET=your_client_secret
REDDIT_USER_AGENT=your_user_agent
```
👉 Get API credentials from **https://www.reddit.com/prefs/apps**  

### 4️⃣ Run the Script
```bash
python reddit_fetcher.py
```

---

## 📤 Example Output
```
Enter subreddit name: Python

🔹 Latest Posts from r/Python 🔹

1. Python 3.12 new features (by JohnDoe)
   Upvotes: 532 | URL: https://reddit.com/r/Python/xyz123

2. Best way to learn Python? (by JaneDoe)
   Upvotes: 321 | URL: https://reddit.com/r/Python/abc456
```
