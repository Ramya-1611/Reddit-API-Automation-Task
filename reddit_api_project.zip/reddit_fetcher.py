import praw
import os
import logging
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(
    filename="reddit_fetcher.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

class RedditAPI:
    """Class to interact with Reddit API using PRAW."""
    
    def __init__(self):
        try:
            # Authenticate with Reddit API
            self.reddit = praw.Reddit(
                client_id=os.getenv("REDDIT_CLIENT_ID"),
                client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
                user_agent=os.getenv("REDDIT_USER_AGENT"),
            )
            logging.info("Successfully authenticated with Reddit API.")
        except Exception as e:
            logging.error(f"Authentication failed: {e}")
            raise SystemExit("Failed to authenticate with Reddit API. Check credentials.")

    def fetch_latest_posts(self, subreddit_name, post_limit=5):
        """Fetch the latest 'post_limit' posts from a given subreddit."""
        try:
            subreddit = self.reddit.subreddit(subreddit_name)
            posts = subreddit.new(limit=post_limit)
            
            post_data = []
            for post in posts:
                post_data.append({
                    "title": post.title,
                    "author": post.author.name,
                    "upvotes": post.score,
                    "url": post.url
                })
            
            logging.info(f"Fetched {len(post_data)} posts from r/{subreddit_name}")
            return post_data
        
        except Exception as e:
            logging.error(f"Failed to fetch posts from r/{subreddit_name}: {e}")
            return []

# Main Execution
if __name__ == "__main__":
    subreddit_name = input("Enter subreddit name: ").strip()
    reddit_api = RedditAPI()
    posts = reddit_api.fetch_latest_posts(subreddit_name)
    
    if posts:
        print("\n🔹 Latest Posts from r/{} 🔹".format(subreddit_name))
        for idx, post in enumerate(posts, start=1):
            print(f"\n{idx}. {post['title']} (by {post['author']})")
            print(f"   Upvotes: {post['upvotes']} | URL: {post['url']}")
    else:
        print(f"❌ No posts found or failed to fetch from r/{subreddit_name}.")
